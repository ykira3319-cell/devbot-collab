const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

let users = [];
let typingUsers = {};

io.on("connection", (socket) => {
  console.log("Nouvel utilisateur connecté:", socket.id);

  socket.on("join", (userData) => {
    socket.username = userData.username;
    socket.photo = userData.photo;
    
    users.push({
      id: socket.id,
      username: userData.username,
      photo: userData.photo
    });
    
    io.emit("user list", users);
    io.emit("chat message", {
      name: "SYSTEM",
      text: userData.username + " a rejoint le groupe",
      photo: "https://i.imgur.com/7bYwF9d.png"
    });
    console.log("Utilisateurs connectés:", users.length);
  });

  socket.on("chat message", (msg) => {
    io.emit("chat message", msg);
  });

  socket.on("typing", () => {
    typingUsers[socket.id] = socket.username;
    socket.broadcast.emit("user typing", Array.from(Object.values(typingUsers)));
  });

  socket.on("stop typing", () => {
    delete typingUsers[socket.id];
    socket.broadcast.emit("user typing", Array.from(Object.values(typingUsers)));
  });

  socket.on("disconnect", () => {
    users = users.filter(u => u.id !== socket.id);
    delete typingUsers[socket.id];
    
    io.emit("user list", users);
    
    if (socket.username) {
      io.emit("chat message", {
        name: "SYSTEM",
        text: socket.username + " a quitté le groupe",
        photo: "https://i.imgur.com/7bYwF9d.png"
      });
    }
    console.log("Utilisateurs connectés:", users.length);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Serveur DevBook lancé sur http://localhost:${PORT}`);
});