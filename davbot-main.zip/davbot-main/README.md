# 🚀 DevBook - Chat Temps Réel

DevBook est une application de chat moderne et responsive en temps réel, construite avec **Node.js**, **Express** et **Socket.IO**.

## ✨ Fonctionnalités

✅ **Authentification** - Créer un compte avec photo de profil  
✅ **Chat temps réel** - Messages instantanés avec Socket.IO  
✅ **Utilisateurs en ligne** - Liste des utilisateurs connectés  
✅ **Indicateur de saisie** - Voir "X est en train d'écrire..."  
✅ **Photos de profil** - Chaque message affiche la photo de l'utilisateur  
✅ **Notifications système** - Alertes d'arrivée/départ d'utilisateurs  
✅ **Design responsive** - Fonctionne sur desktop, tablette et mobile  
✅ **Interface moderne** - Design dark mode avec gradients  

## 📁 Structure du Projet

```
devbook/
├── server.js              # Serveur Node.js + Socket.IO
├── package.json           # Dépendances du projet
├── README.md              # Ce fichier
└── public/
    ├── login.html         # Page de connexion
    ├── register.html      # Page d'inscription
    ├── home.html          # Page d'accueil
    └── chat.html          # Page du chat (temps réel)
```

## 🔧 Installation

### Prérequis
- **Node.js** (v14 ou plus) - [Télécharger](https://nodejs.org/)
- **npm** (inclus avec Node.js)

### Étapes

1. **Cloner le repository**
```bash
git clone https://github.com/ykira3319-cell/davbot.git
cd davbot
```

2. **Installer les dépendances**
```bash
npm install
```

3. **Lancer le serveur**
```bash
npm start
```

Le serveur démarre sur `http://localhost:3000`

4. **Accéder à l'application**
Ouvrez votre navigateur et allez à `http://localhost:3000`

## 🚀 Utilisation

### 1. **Créer un compte**
- Cliquez sur "Créer un compte"
- Remplissez: nom, email, mot de passe, photo de profil
- Vous êtes automatiquement connecté et redirigé vers l'accueil

### 2. **Se connecter**
- Page de connexion avec email et mot de passe
- Redirection vers l'accueil après connexion

### 3. **Accueil**
- Affiche votre profil (nom, email, photo)
- Fonctionnalités disponibles listées
- Bouton pour accéder au chat

### 4. **Chat**
- **Sidebar gauche** - Liste des utilisateurs en ligne
- **Zone principale** - Messages et chat
- **Indicateur de saisie** - Voir qui tape un message
- **Input en bas** - Envoyer des messages

## 🛠️ Développement

Pour développer avec rechargement automatique:

```bash
npm run dev
```

(Nécessite `nodemon` - installé automatiquement avec `npm install`)

## 📝 Technologie

- **Backend**: Node.js + Express.js
- **Real-time**: Socket.IO v4.5.4
- **Frontend**: HTML5 + CSS3 + JavaScript vanilla
- **Stockage**: LocalStorage (navigateur)

## 🎨 Design

- **Couleurs principales**: Bleu (#1877f2) et Vert (#42b72a)
- **Thème**: Dark mode moderne avec gradients
- **Responsive**: Mobile-first, optimisé pour tous les écrans
- **Animations**: Transitions fluides et indicateurs animés

## 📱 Responsive Design

✅ Desktop (1200px+)  
✅ Tablette (768px - 1199px)  
✅ Mobile (320px - 767px)  

## 🔐 Sécurité

⚠️ **Note**: Ce projet est une démo. Pour la production:
- Utiliser une vraie base de données (MongoDB, PostgreSQL)
- Hacher les mots de passe (bcrypt)
- Implémenter JWT pour l'authentification
- Valider les entrées côté serveur
- Utiliser HTTPS/WSS

## 🎯 Améliorations futures

- [ ] Base de données persistante
- [ ] Authentification JWT
- [ ] Chiffrement des messages
- [ ] Historique des messages
- [ ] Salons de discussion
- [ ] Partage de fichiers
- [ ] Notifications push
- [ ] Mode sombre/clair

## 📄 Licence

MIT - Libre d'utilisation

## 👨‍💻 Auteur

octavio wina- 2026

---

**Besoin d'aide?** Consultez la documentation de [Socket.IO](https://socket.io/docs/) ou [Express.js](https://expressjs.com/)
